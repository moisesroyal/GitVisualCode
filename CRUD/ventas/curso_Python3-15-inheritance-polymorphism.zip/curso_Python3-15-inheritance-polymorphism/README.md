# Platzi ventas (curso de Python)
